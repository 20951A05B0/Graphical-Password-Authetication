
# Graphical-Password-Authentication-Prototype

We the team of six developed Graphical Password Authentication System || Smart India Hackathon



- A Graphical Password Authentication system is an authentication system that uses some combination of graphical images replacing the regular passwords. Graphical passwords may offer better security than text-based passwords because most of the people use regular, popular passwords everywhere and are prone to social engineering attacks. So graphical passwords can put stop to many attacks of this kind.





## Team ✨

- Saransh Vashisht

- Sushant Kumar

- Sourabh Tripathi

- Rahul Kushwaha

- Ramakant Kumar

- Ash Aggarwal


## Screenshots📸


### Account creation
![Account creation](https://github.com/saransh-vashisht/Graphical-Pasword-Authentication-Prototype/blob/main/screenshots/account%20creation.png?raw=true)

### Login sucess
![Login sucessful](https://github.com/saransh-vashisht/Graphical-Pasword-Authentication-Prototype/blob/main/screenshots/login%20success.png?raw=true)


### Login Failure
![Login failure](https://github.com/saransh-vashisht/Graphical-Pasword-Authentication-Prototype/blob/main/screenshots/Login%20failed.png?raw=true)

### Login Failure Notification
![Login failure notifs](https://github.com/saransh-vashisht/Graphical-Pasword-Authentication-Prototype/blob/main/screenshots/Login%20fail%20notification.png?raw=true)


### Password Reset Notification
![Password notification](https://github.com/saransh-vashisht/Graphical-Pasword-Authentication-Prototype/blob/main/screenshots/Password%20reset.png?raw=true)
